package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {

	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices= new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails( int yearlyInvestmentUnder80C,String firstName, String lastName,String department, String designation, String pancard, String emailId,float basicSalary, float epf, float companyPf,int accountNumber,String bankName, String ifscCode)
	{

		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber,bankName,ifscCode)));

	}
	public float calculateNetSalary(int associateId) {
		Associate associate=this.getAssociateDetails(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
						float grosssalary= associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra();
			float annualtax;
			float annualsalary=grosssalary;			
			if(associate.getYearlyInvestmentUnder80C()>=(150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())) 
				associate.setYearlyInvestmentUnder80C((int) (150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()));
			else 
				associate.setYearlyInvestmentUnder80C((int) (associate.getYearlyInvestmentUnder80C()+associate.getSalary().getEpf()+associate.getSalary().getCompanyPf()));
			if(annualsalary>0 && annualsalary<=250000) {
				annualtax= 0;
				associate.getSalary().setNetSalary(annualsalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return associate.getSalary().getNetSalary();
			}
			else if(annualsalary>250000&&annualsalary<=500000) {
				annualtax= (annualsalary-250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f;
				associate.getSalary().setNetSalary(annualsalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}
			else if(annualsalary>500000&&annualsalary<=1000000) {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+(annualsalary-500000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.2f);
				associate.getSalary().setNetSalary(annualsalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}
			else {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+(500000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.2f+(annualsalary-1000000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.3f);
				associate.getSalary().setNetSalary(annualsalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}		
		}
		return 0;
	}


	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);
	}
	public Associate[] getAssociateDetails(){
		return null;
	}
}










