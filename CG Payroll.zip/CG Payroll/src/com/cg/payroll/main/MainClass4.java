package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.services.*;
public class MainClass4 {

	public static void main(String[] args) {
	PayrollServicesImpl payrollServicesImpl=new PayrollServicesImpl(); 
 int associateId = payrollServicesImpl.acceptAssociateDetails(12000, "mani", "red", "eee", "high", "HYU78", "mani.com", 237660, 1970, 1100, 12322, "gyf", "cutu67");

 //System.out.println("id");
System.out.println(payrollServicesImpl.calculateNetSalary(111));
	
	}

}

//SEARCHING BY NAME

/*String associateFirstName="kiran";
Associate associate=SearchAssociateFirstName(associateFirstName);
if(associate!=null){
	System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "+associate.getYearlyInvestmentUnder80C());
}
else
	System.out.println("details of"+" "+associateFirstName +" "+ "not found");

	}
public static Associate SearchAssociateFirstName(String associateFirstName) {
Associate[] associates=new Associate[4];
associates[0]=new Associate(123, 23, "kiran","reddy","eee", "analyst", "FGHH5373", "mani@gmail.com");
associates[1]=new Associate(124, 500, "mani","reddy","ece", "trainer", "FGHH5373", "mani@gmail.com");
associates[2]=new Associate(125, 55000, "kiran","reddy","bee", "teacher", "FGHH5373", "mani@gmail.com");


for(Associate associate:associates)
 if(associate!=null&&
 associate.getFirstName()==associateFirstName&&associate.getYearlyInvestmentUnder80C()>=5000)
	
	 return associate;
			 return null;
}*/


//ID SEARCHING

/*	int associateIdToBeSearch=123;
				Associate associate=SearchAssociateID(associateIdToBeSearch);
				if(associate!=null){
					System.out.println(associate.getFirstName()+" "+associate.getLastName());
				}
				else
					System.out.println("details of"+" "+ associateIdToBeSearch+" "+ "not found");

					}
			public static Associate SearchAssociateID(int associateID) {
				Associate[] associates=new Associate[4];
				associates[0]=new Associate(123, 23, "kiran","reddy","eee", "analyst", "FGHH5373", "mani@gmail.com");
				associates[1]=new Associate(124, 500, "mani","reddy","ece", "trainer", "FGHH5373", "mani@gmail.com");
				associates[2]=new Associate(125, 55000, "anusha","reddy","bee", "teacher", "FGHH5373", "mani@gmail.com");
			 for(Associate associate:associates)
				 if(associate!=null&&
				 associate.getAssociateID()==associateID)
					 return associate;
							 return null;
			}
*/		



